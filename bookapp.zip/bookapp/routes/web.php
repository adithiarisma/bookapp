<?php


$router->get('books', 'BooksController@index');
$router->get('/books/{id}', 'BooksController@show');
$router->get('/', function () use ($router) {
    return $router->app->version();
});
$router->get('/key', function() {
    return \Illuminate\Support\Str::random(32);
});




