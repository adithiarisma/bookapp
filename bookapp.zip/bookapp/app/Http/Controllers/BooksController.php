<?php


namespace App\Http\Controllers;
use App\Models\Book;

class BooksController extends Controller{

public function index ()
{
  return Book::all();
}


public function show ($id) //per ID (1)
{
  if($book = Book::find($id)){
    return $book;
}else{
  return response('Book Not Found', 404);
  
}
}

}

